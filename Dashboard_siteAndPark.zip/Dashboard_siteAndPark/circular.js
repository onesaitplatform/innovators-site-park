//Write your controller (JS code) code here

//Focus here and F11 to full screen editor

//This function will be call once to init components
vm.initLiveComponent = function(){
    $scope.$watchCollection('vm.datastatus', vm.refreshValues);
}

vm.refreshValues = function(){
var dom = document.getElementById("satisfaccion");
vm.myChart = echarts.init(dom);
var app = {};
vm.option = {
    xAxis: {type: 'category'
            },
    yAxis: {type: 'value'
            },
    // Declare several bar series, each will be mapped
    // to a column of dataset.source by default.
    series: [
        {type: 'bar'}
    ]
};

if (vm.option && typeof vm.option === "object") {
    vm.myChart.setOption(vm.option, true);
	vm.myChart.resize()
}
};

//This function will be call when data change. On first execution oldData will be null
vm.drawLiveComponent = function(newData, oldData){
var dom = document.getElementById("satisfaccion");
vm.myChart = echarts.init(dom);
var app = {};
vm.option = null;
vm.option = {
    title: {
        text: 'Satisfacción empleados',
        left: 'center'
    },
    tooltip: {
        trigger: 'item',
        formatter: '{a} <br/>{b} : {c} ({d}%)'
    },
    legend: {
        orient: 'horizontal',
        left: 'center',
        top: '8%',
        data: ['Muy satisfecho', 'Satisfecho', 'Insatisfecho', 'Muy insatisfecho', 'NS/NR']
    },
    series: [
        {
            name: 'satisfaccion',
            type: 'pie',
            radius: '55%',
            center: ['50%', '60%'],
            data: [
                {value: 1150, name: 'Muy satisfecho'},
                {value: 600, name: 'Satisfecho'},
                {value: 250, name: 'Insatisfecho'},
                {value: 140, name: 'Muy insatisfecho'},
                {value: 400, name: 'NS/NR'}
            ],
            emphasis: {
                itemStyle: {
                    shadowBlur: 10,
                    shadowOffsetX: 0,
                    shadowColor: 'rgba(0, 0, 0, 0.5)'
                }
            }
        }
    ]
};
;
if (vm.option && typeof vm.option === "object") {
    vm.myChart.setOption(vm.option, true);
    vm.myChart.resize()
}
};

//This function will be call on element resize
vm.resizeEvent = function(){
	vm.myChart.resize();
}

//This function will be call when element is destroyed
vm.destroyLiveComponent = function(){
    if(vm.myChart){
    	vm.myChart.clear();
  		vm.myChart = null;
    }
};

//This function will be call when receiving a value from vm.sendValue(idGadgetTarget,data)
vm.receiveValue = function(data){

};