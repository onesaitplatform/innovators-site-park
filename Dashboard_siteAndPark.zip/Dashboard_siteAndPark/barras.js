//Write your controller (JS code) code here

//Focus here and F11 to full screen editor

//This function will be call once to init components
vm.initLiveComponent = function(){
    $scope.$watchCollection('vm.datastatus', vm.refreshValues);
}

vm.refreshValues = function(){
var dom = document.getElementById("ocupacion");
vm.myChart = echarts.init(dom);
var app = {};
vm.option = {
    xAxis: {type: 'category'
            },
    yAxis: {type: 'value'
            },
    // Declare several bar series, each will be mapped
    // to a column of dataset.source by default.
    series: [
        {type: 'bar'}
    ]
};

if (vm.option && typeof vm.option === "object") {
    vm.myChart.setOption(vm.option, true);
	vm.myChart.resize()
}
};

//This function will be call when data change. On first execution oldData will be null
vm.drawLiveComponent = function(newData, oldData){
var dom = document.getElementById("ocupacion");
vm.myChart = echarts.init(dom);
var app = {};
vm.option = null;
vm.option = {
    tooltip: {
        trigger: 'axis',
        axisPointer: {
            type: 'shadow'
        }
    },
    legend: {
        data: ['Ocupada', 'Pdte. desinfectar', 'Libre'],
        top: '7%'
    },
    title: {
        text: 'Evolución por hora de la ocupación de las salas',
        left: 'center'
    },
    grid: {
        top: '14%',
        left: '3%',
        right: '4%',
        bottom: '3%',
        containLabel: true
    },
    xAxis: {
        type: 'category',
        data: ['13:00', '14:00', '15:00', '16:00', '17:00', '18:00', '19:00']
    },
    yAxis: {
        type: 'value'
    },
    series: [
        {
            name: 'Ocupada',
            type: 'bar',
            stack: 'salas',
            label: {
                show: true,
                position: 'inside'
            },
            data: [320, 302, 301, 334, 390, 330, 320],
            color: '#ef0b0b'
        },
        {
            name: 'Pdte. desinfectar',
            type: 'bar',
            stack: 'salas',
            label: {
                show: true,
                position: 'inside'
            },
            data: [120, 132, 101, 134, 90, 230, 210],
            color: '#f4dc02'
        },
        {
            name: 'Libre',
            type: 'bar',
            stack: 'salas',
            label: {
                show: true,
                position: 'inside'
            },
            data: [220, 182, 191, 234, 290, 330, 310],
            color: '#47b72c'
        }
    ]
};
;
if (vm.option && typeof vm.option === "object") {
    vm.myChart.setOption(vm.option, true);
    vm.myChart.resize()
}
};

//This function will be call on element resize
vm.resizeEvent = function(){
	vm.myChart.resize();
}

//This function will be call when element is destroyed
vm.destroyLiveComponent = function(){
    if(vm.myChart){
    	vm.myChart.clear();
  		vm.myChart = null;
    }
};

//This function will be call when receiving a value from vm.sendValue(idGadgetTarget,data)
vm.receiveValue = function(data){

};